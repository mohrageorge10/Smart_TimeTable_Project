class ScheduleModeConfig {
  final String modeName;
  final String nameLabel;
  final String personLabel;
  final bool hasCapacity;
  final bool hasLocationSettings;
  final bool hasLocationType;

  final List<String> types;
  final List<String> specialties;
  final bool hasAcademicYear;
  final String? academicYearLabel;
  final List<String>? locations;
  final List<String>? academicYears;
  final String? typeLabel;
  final String? SpecialtyLabel;

  // ── جديد: الـ sub-levels الديناميكية ─────────────────────
  /// هل يوجد حقل "section / class" ديناميكي يتغير بناءً على الـ level؟
  final bool hasDynamicSection;
  /// label الحقل الديناميكي (مثلاً "Section" للكلية أو "Class" للمدرسة)
  final String? sectionLabel;
  /// دالة ترجع خيارات الـ section بناءً على الـ level المختار
  final List<String> Function(String level)? getSectionsForLevel;

  /// هل يوجد اختيار أيام التوافر لكل مادة؟
  final bool hasAvailableDays;
  /// الأيام المستثناة من هذا الـ mode (مثلاً Friday للكلية)
  final List<String> excludedDays;

  ScheduleModeConfig({
    required this.modeName,
    required this.nameLabel,
    required this.personLabel,
    required this.hasCapacity,
    required this.hasLocationSettings,
    required this.hasLocationType,
    required this.types,
    required this.specialties,
    required this.hasAcademicYear,
    this.academicYearLabel,
    this.locations,
    this.academicYears,
    this.typeLabel,
    this.SpecialtyLabel,
    // جديد
    this.hasDynamicSection = false,
    this.sectionLabel,
    this.getSectionsForLevel,
    this.hasAvailableDays = false,
    this.excludedDays = const [],
  });
}
