import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:frontend/features/schedule/data/repos/mode_repo.dart'; // تأكدي من مسار ملف الريبو
import 'package:frontend/features/schedule/data/repos/schedule_repository.dart';
import 'schedule_state.dart';

class ScheduleCubit extends Cubit<ScheduleState> {
  final ScheduleRepository repository;
  String currentMode = 'College'; 

  String courseName = '';
  String lecturerName = '';
  int studentsCount = 0;
  String? selectedType;
  String? selectedSpecialty;
  String? selectedYear;
  String? targetAudience;

  int numberOfSlots = 0;
  int slotDuration = 0;
  String startTime = '';
  int breakDuration = 0;

  String locationName = '';
  int locationCapacity = 0;
  String locationType = '';

  Map<String, Map<String, dynamic>> addedItems = {};
  List<Map<String, dynamic>> addedLocations = [];

  ScheduleCubit(this.repository) : super(ScheduleInitial());

  void addItemToList() {
    if (courseName.isEmpty) return;

    // سحب الإعدادات الخاصة بالمود الحالي من الريبو
    final config = ModeRepository.modes[currentMode]!;

    // تحديد القيمة الخاصة بخانة السنة/الجمهور
    final academicOrAudienceValue = (currentMode == 'Event') ? targetAudience : selectedYear;

    addedItems[courseName] = {
      config.nameLabel: courseName,
      config.personLabel: lecturerName,
      
      if (config.hasCapacity) "Capacity": studentsCount.toString(),
      if (selectedType != null) "Type": selectedType,
      
      // استخدام ذكي للـ Label اللي في الريبو
      if (config.hasAcademicYear && academicOrAudienceValue != null) 
        config.academicYearLabel!: academicOrAudienceValue,
    };
    
    emit(ScheduleInitial());
  }

  void addLocationToList() {
    if (locationName.isEmpty) return;
    addedLocations.add({
      "name": locationName,
      "capacity": locationCapacity,
      "type": locationType,
    });
    emit(ScheduleInitial());
  }

  void refreshUI() => emit(ScheduleInitial());

  void generateSchedule() async {
    emit(ScheduleLoading());
  }
}