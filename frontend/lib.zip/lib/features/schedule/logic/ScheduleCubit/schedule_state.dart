import 'package:equatable/equatable.dart';
import 'package:frontend/features/schedule/data/models/schedule_item.dart';

abstract class ScheduleState extends Equatable {
  const ScheduleState();
  @override
  List<Object> get props => [];
}

class ScheduleInitial extends ScheduleState {}
class ScheduleLoading extends ScheduleState {}
class ScheduleLoaded extends ScheduleState {
  final List<ScheduleItem> schedule;
  const ScheduleLoaded(this.schedule);
  @override
  List<Object> get props => [schedule];
}
class ScheduleError extends ScheduleState {
  final String message;
  const ScheduleError(this.message);
  @override
  List<Object> get props => [message];
}