// import 'package:flutter/material.dart';
// import 'package:flutter_bloc/flutter_bloc.dart';
// import 'package:frontend/core/constants/app_data.dart';
// import 'package:frontend/features/schedule/logic/ScheduleCubit/schedule_cubit.dart';
// import 'package:frontend/features/schedule/logic/ScheduleCubit/schedule_state.dart';class ScheduleTable extends StatelessWidget {
//   const ScheduleTable({super.key});

//   @override
//   Widget build(BuildContext context) {
//     return BlocBuilder<ScheduleCubit, ScheduleState>(
//       builder: (context, state) {
//         // 1. حالة البداية
//         if (state is ScheduleInitial) {
//           return const Center(child: Text("Enter data and click Generate"));
//         } 
//         // 2. حالة التحميل
//         else if (state is ScheduleLoading) {
//           return const Center(child: CircularProgressIndicator());
//         } 
//         // 3. حالة الخطأ
//         else if (state is ScheduleError) {
//           return Center(child: Text(state.message, style: const TextStyle(color: Colors.red)));
//         } 
//         // 4. حالة عرض الجدول (هنا السحر كله)
//         else if (state is ScheduleLoaded) {
//           final schedule = state.schedule;

//           return SingleChildScrollView(
//             child: SingleChildScrollView(
//               child: Card(
//                 elevation: 4,
//                 margin: const EdgeInsets.all(16),
//                 child: DataTable(
//                   headingRowColor: MaterialStateProperty.all(Theme.of(context).primaryColor.withOpacity(0.1)),
//                   border: TableBorder.all(color: Colors.grey.shade300, width: 1),
                  
//                   columns: [
//                     const DataColumn(label: Text("Day", style: TextStyle(fontWeight: FontWeight.bold))),
//                     ...AppData.timeslots.map((time) => DataColumn(
//                       label: Text(time, style: const TextStyle(fontWeight: FontWeight.bold)),
//                     )),
//                   ],

//                   rows: AppData.days.map((day) {
//                     return DataRow(
//                       cells: [
//                         DataCell(
//                           Text(day, style: TextStyle(fontWeight: FontWeight.bold, color: Theme.of(context).primaryColor)),
//                         ),
                        
//                         ...AppData.timeslots.map((time) {
//                           final item = _getCourseForTime(schedule, day, time);
                          
//                           if (item != null) {
//                             return DataCell(
//                               Container(
//                                 padding: const EdgeInsets.all(4),
//                                 child: Column(
//                                   mainAxisAlignment: MainAxisAlignment.center,
//                                   crossAxisAlignment: CrossAxisAlignment.start,
//                                   children: [
//                                     Text(item.name, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
//                                     Text("${item.room} - ${item.person}", style: const TextStyle(fontSize: 11, color: Colors.grey)),
//                                   ],
//                                 ),
//                               ),
//                             );
//                           } else {
//                             return const DataCell(Center(child: Text("-", style: TextStyle(color: Colors.grey))));
//                           }
//                         }),
//                       ],
//                     );
//                   }).toList(),
//                 ),
//               ),
//             ),
//           );
//         }
//         return const SizedBox();
//       },
//     );
//   }
//   dynamic _getCourseForTime(List<dynamic> schedule, String day, String time) {
//     try {
//       return schedule.firstWhere((element) => element.day == day && element.slot == time);
//     } catch (e) {
//       return null;
//     }
//   }
// }