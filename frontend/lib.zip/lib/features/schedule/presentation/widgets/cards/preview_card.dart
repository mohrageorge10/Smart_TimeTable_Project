import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:frontend/core/routing/app_routes.dart';
import 'package:frontend/features/schedule/logic/ScheduleCubit/schedule_cubit.dart';
import 'package:frontend/features/schedule/presentation/widgets/cards/section_card.dart';

class PreviewCard extends StatelessWidget {
  const PreviewCard({super.key});

  @override
  Widget build(BuildContext context) {
    final cubit = context.watch<ScheduleCubit>();

    return SectionCard(
      title: "Data Preview",
      icon: Icons.preview,
      children: [
        // Items List
        if (cubit.addedItems.isNotEmpty) ...[
          const Text(
            "Added Items:",
            style: TextStyle(fontWeight: FontWeight.bold),
          ),
          ...cubit.addedItems.entries.map(
            (entry) => Card(
              child: ListTile(
                title: Text(entry.key),
                onTap: () => Navigator.pushNamed(
                  context,
                  AppRoutes.details,
                  arguments: {
                    'itemName': entry.key,
                    'details': entry.value,
                    'cubit': cubit,
                  },
                ),
                trailing: IconButton(
                  icon: const Icon(Icons.delete, color: Colors.red),
                  onPressed: () {
                    cubit.addedItems.remove(entry.key);
                    cubit.refreshUI();
                  },
                ),
              ),
            ),
          ),
        ],
      ],
    );
  }
}
