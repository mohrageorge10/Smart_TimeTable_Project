import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:frontend/core/constants/app_strings.dart';
import 'package:frontend/core/utils/size_config.dart';
// تأكدي من استدعاء مسار الريبو بشكل صحيح
import 'package:frontend/features/schedule/data/repos/mode_repo.dart';
import 'package:frontend/features/schedule/logic/ScheduleCubit/schedule_cubit.dart';
import 'package:frontend/features/schedule/logic/modeCubit/mode_cubit.dart';
import 'package:frontend/features/schedule/presentation/widgets/cards/section_card.dart';
import 'package:frontend/features/schedule/presentation/widgets/custom_dropdown.dart';
import 'package:frontend/features/schedule/presentation/widgets/custom_text_field.dart';

class BasicInfoCard extends StatelessWidget {
  const BasicInfoCard({super.key});

  @override
  Widget build(BuildContext context) {
    final cubit = context.read<ScheduleCubit>();
    final currentMode = context.read<ModeCubit>().state.selectedMode;

    // سحب الإعدادات الخاصة بالمود الحالي من الريبو
    final config = ModeRepository.modes[currentMode]!;

    return SectionCard(
      title: AppStrings.basicInfo,
      icon: Icons.info_outline,
      children: [
        CustomTextField(
          labelText: config.nameLabel,
          prefixIcon: Icons.menu_book,
          onChanged: (value) => cubit.courseName = value,
        ),
        SizedBox(height: 1.5.h),
        CustomTextField(
          labelText: config.personLabel,
          prefixIcon: Icons.person,
          onChanged: (value) => cubit.lecturerName = value,
        ),
        SizedBox(height: 1.5.h),

        Row(
          children: [
            if (config.hasCapacity) ...[
              Expanded(
                child: CustomTextField(
                  labelText: "Capacity",
                  prefixIcon: Icons.groups,
                  keyboardType: TextInputType.number,
                  onChanged: (value) =>
                      cubit.studentsCount = int.tryParse(value) ?? 0,
                ),
              ),
              SizedBox(width: 2.w),
            ],

            Expanded(
              child: CustomDropdown(
                labelText: "Type",
                prefixIcon: Icons.category,
                items: config.types,
                value: cubit.selectedType,
                onChanged: (val) => cubit.selectedType = val,
              ),
            ),
          ],
        ),
        SizedBox(height: 1.5.h),

        // عرض التخصصات من الريبو
        if (config.specialties.isNotEmpty) ...[
          CustomDropdown(
            labelText: "Specialty",
            prefixIcon: Icons.star,
            items: config.specialties,
            value: cubit.selectedSpecialty,
            onChanged: (val) => cubit.selectedSpecialty = val,
          ),
          SizedBox(height: 1.5.h),
        ],

        // عرض السنة الدراسية أو الجمهور المستهدف من الريبو
        if (config.hasAcademicYear && config.academicYears != null) ...[
          CustomDropdown(
            labelText: config.academicYearLabel ?? "Academic Year",
            prefixIcon: Icons.school,
            items: config.academicYears!,
            value: cubit.selectedYear,
            onChanged: (val) => cubit.selectedYear = val,
          ),
          SizedBox(height: 1.5.h),
        ],
      ],
    );
  }
}
