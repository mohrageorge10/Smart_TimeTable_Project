import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:frontend/core/constants/app_strings.dart';
import 'package:frontend/core/utils/size_config.dart';
// تأكدي من استدعاء مسار الريبو بشكل صحيح
import 'package:frontend/features/schedule/data/repos/mode_repo.dart';
import 'package:frontend/features/schedule/logic/ScheduleCubit/schedule_cubit.dart';
import 'package:frontend/features/schedule/logic/modeCubit/mode_cubit.dart';
import 'package:frontend/features/schedule/presentation/widgets/cards/section_card.dart';
import 'package:frontend/features/schedule/presentation/widgets/custom_dropdown.dart';
import 'package:frontend/features/schedule/presentation/widgets/custom_text_field.dart';

class LocationSettingsCard extends StatelessWidget {
  const LocationSettingsCard({super.key});

  @override
  Widget build(BuildContext context) {
    final cubit = context.read<ScheduleCubit>();
    final currentMode = context.read<ModeCubit>().state.selectedMode;

    // سحب الإعدادات
    final config = ModeRepository.modes[currentMode]!;

    return SectionCard(
      title: AppStrings.locationSettings,
      icon: Icons.location_on_outlined,
      children: [
        CustomTextField(
          labelText: "Location Name", // توحيد الاسم أفضل
          prefixIcon: Icons.meeting_room,
          onChanged: (value) => cubit.locationName = value,
        ),
        SizedBox(height: 1.5.h),
        Row(
          children: [
            Expanded(
              child: CustomTextField(
                labelText: "Capacity",
                prefixIcon: Icons.groups_2,
                keyboardType: TextInputType.number,
                onChanged: (value) =>
                    cubit.locationCapacity = int.tryParse(value) ?? 0,
              ),
            ),

            // شرط ذكي بيسحب القوائم من الريبو بدون if/else معقدة
            if (config.hasLocationType && config.locations != null) ...[
              SizedBox(width: 2.w),
              Expanded(
                child: CustomDropdown(
                  labelText: "Location Type",
                  prefixIcon: Icons.place,
                  items: config.locations!, // 👈 هنا القائمة الديناميكية
                  value: cubit.locationType.isEmpty ? null : cubit.locationType,
                  onChanged: (val) => cubit.locationType = val ?? "",
                ),
              ),
            ],
          ],
        ),
        SizedBox(height: 1.5.h),
      ],
    );
  }
}
