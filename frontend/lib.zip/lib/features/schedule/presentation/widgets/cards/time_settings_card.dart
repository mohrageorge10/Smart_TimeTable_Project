import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:frontend/core/constants/app_strings.dart';
import 'package:frontend/core/utils/size_config.dart';
import 'package:frontend/features/schedule/logic/ScheduleCubit/schedule_cubit.dart';
import 'package:frontend/features/schedule/presentation/widgets/cards/section_card.dart';
import 'package:frontend/features/schedule/presentation/widgets/custom_text_field.dart';

// 1. حولناها لـ StatefulWidget عشان نتحكم في الـ Text Controller
class TimeSettingsCard extends StatefulWidget {
  const TimeSettingsCard({super.key});

  @override
  State<TimeSettingsCard> createState() => _TimeSettingsCardState();
}

class _TimeSettingsCardState extends State<TimeSettingsCard> {
  // 2. عملنا Controller عشان نحدث النص جوه الخانة بعد اختيار الوقت
  final TextEditingController _timeController = TextEditingController();

  @override
  void dispose() {
    _timeController.dispose();
    super.dispose();
  }

  // 3. دالة فتح الساعة
  Future<void> _selectTime(BuildContext context, ScheduleCubit cubit) async {
    final TimeOfDay? picked = await showTimePicker(
      context: context,
      initialTime: TimeOfDay.now(),
    );

    if (picked != null && context.mounted) {
      // picked.format بتحول الوقت لصيغة 12 ساعة (AM/PM) أوتوماتيك
      final formattedTime = picked.format(context); 
      
      setState(() {
        _timeController.text = formattedTime; // بنعرض الوقت في الـ TextField
        cubit.startTime = formattedTime;      // بنحفظ الوقت في الكيوبيت
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final cubit = context.read<ScheduleCubit>();

    return SectionCard(
      title: AppStrings.timeSettings,
      icon: Icons.access_time,
      children: [
        Row(
          children: [
            Expanded(
              child: CustomTextField(
                labelText: "Slots Count",
                prefixIcon: Icons.format_list_numbered,
                keyboardType: TextInputType.number,
                onChanged: (value) =>
                    cubit.numberOfSlots = int.tryParse(value) ?? 0,
              ),
            ),
            SizedBox(width: 2.w),
            Expanded(
              child: CustomTextField(
                labelText: "Duration (min)",
                prefixIcon: Icons.timer,
                keyboardType: TextInputType.number,
                onChanged: (value) =>
                    cubit.slotDuration = int.tryParse(value) ?? 0,
              ),
            ),
          ],
        ),
        SizedBox(height: 1.5.h),
        Row(
          children: [
            Expanded(
              // 4. حوطنا الـ CustomTextField بـ GestureDetector عشان نقبض على الضغطة
              child: GestureDetector(
                onTap: () => _selectTime(context, cubit),
                child: AbsorbPointer(
                  child: CustomTextField(
                    labelText: "Start Time",
                    prefixIcon: Icons.play_circle_outline,
                    controller: _timeController, // ربطنا الكنترولر بالخانة
                  ),
                ),
              ),
            ),
            SizedBox(width: 2.w),
            Expanded(
              child: CustomTextField(
                labelText: "Break (min)",
                prefixIcon: Icons.pause_circle_outline,
                keyboardType: TextInputType.number,
                onChanged: (value) =>
                    cubit.breakDuration = int.tryParse(value) ?? 0,
              ),
            ),
          ],
        ),
      ],
    );
  }
}