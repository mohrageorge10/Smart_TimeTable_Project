import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:frontend/core/utils/size_config.dart';
import 'package:frontend/features/schedule/logic/ScheduleCubit/schedule_cubit.dart';
import 'package:frontend/features/schedule/logic/ScheduleCubit/schedule_state.dart';
import 'package:frontend/features/schedule/logic/modeCubit/mode_cubit.dart';
import 'package:frontend/features/schedule/data/repos/mode_repo.dart';
import 'package:frontend/features/schedule/presentation/widgets/cards/basic_info_card.dart';
import 'package:frontend/features/schedule/presentation/widgets/cards/location_settings_card.dart';
import 'package:frontend/features/schedule/presentation/widgets/cards/preview_card.dart';
import 'package:frontend/features/schedule/presentation/widgets/cards/time_settings_card.dart';
import 'package:frontend/features/schedule/presentation/widgets/generate_schedule_button.dart';
import 'package:frontend/features/schedule/presentation/widgets/preview_button.dart';

class InputSection extends StatelessWidget {
  const InputSection({super.key});

  @override
  Widget build(BuildContext context) {
    final currentMode = context.read<ModeCubit>().state.selectedMode;
    final config = ModeRepository.modes[currentMode]!;

    return BlocBuilder<ScheduleCubit, ScheduleState>(
      builder: (context, state) {
        final cubit = context.read<ScheduleCubit>();

        return Container(
          padding: EdgeInsets.all(3.w),
          color: Colors.grey[100],
          child: ListView(
            children: [
              const BasicInfoCard(),
              SizedBox(height: 2.h),

              const TimeSettingsCard(),
              SizedBox(height: 2.h),

              if (config.hasLocationSettings) ...[
                const LocationSettingsCard(),
                SizedBox(height: 2.h),
              ],

              if (cubit.addedItems.isNotEmpty ||
                  cubit.addedLocations.isNotEmpty ||
                  cubit.numberOfSlots > 0 ||
                  cubit.startTime.isNotEmpty) ...[
                const PreviewCard(),
                SizedBox(height: 3.h),
              ],
              PreviewButton(cubit: cubit),
              SizedBox(height: 3.h),
              GenerateScheduleButton(cubit: cubit),
            ],
          ),
        );
      },
    );
  }
}