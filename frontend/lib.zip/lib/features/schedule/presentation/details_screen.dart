import 'package:flutter/material.dart';
import 'package:frontend/features/schedule/logic/ScheduleCubit/schedule_cubit.dart';
import 'package:frontend/features/schedule/data/repos/mode_repo.dart'; 

class DetailsScreen extends StatelessWidget {
  final String itemName;
  final Map<String, dynamic> details;
  final ScheduleCubit cubit;

  const DetailsScreen({
    super.key, 
    required this.itemName, 
    required this.details, 
    required this.cubit,
  });

  @override
  Widget build(BuildContext context) {
    final config = ModeRepository.modes[cubit.currentMode]!;

    return Scaffold(
      appBar: AppBar(title: Text("$itemName Details")),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          _buildSection("Item Details", details, context),
          
          _buildSection("Time Settings", {
            "Slots": cubit.numberOfSlots.toString(),
            "Duration": "${cubit.slotDuration} min",
            "Start Time": cubit.startTime.isEmpty ? "Not set" : cubit.startTime,
            "Break": "${cubit.breakDuration} min",
          }, context),
          
          if (config.hasLocationSettings)
            _buildSection("Locations", {
              "Total Locations": cubit.addedLocations.length.toString(),
              "Info": cubit.addedLocations.isEmpty 
                  ? "No locations added yet." 
                  : cubit.addedLocations.map((l) => "${l['name']} (${l['capacity']})").join("\n"),
            }, context),
        ],
      ),
    );
  }

  Widget _buildSection(String title, Map<String, dynamic> data, BuildContext context) {
    return Card(
      margin: const EdgeInsets.only(bottom: 16),
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              title, 
              style: TextStyle(
                fontSize: 18, 
                fontWeight: FontWeight.bold, 
                color: Theme.of(context).primaryColor,
              ),
            ),
            const Divider(),
            ...data.entries.map((e) => Padding(
              padding: const EdgeInsets.symmetric(vertical: 4),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text("${e.key}: ", style: const TextStyle(fontWeight: FontWeight.bold)),
                  Expanded(
                    child: Text(e.value.toString()),
                  ),
                ],
              ),
            )),
          ],
        ),
      ),
    );
  }
}