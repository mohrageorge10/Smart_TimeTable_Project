import 'package:frontend/features/schedule/data/repos/mode_repo.dart';

class MockDataService {
  static Map<String, dynamic> getMockDataForMode(String mode) {
    final config = ModeRepository.modes[mode] ?? ModeRepository.modes['College']!;

    Map<String, dynamic> data = {
      "locations": <Map<String, dynamic>>[],
      "items": <String, Map<String, dynamic>>{},
      "startTime": "08:00 AM",
      "numberOfSlots": 5,
      "slotDuration": 90,
      "breakDuration": 10,
    };

    if (mode == 'College') {
      data["locations"] = [
        {"name": "Main Hall", "capacity": 300, "type": "Lecture Hall"},
        {"name": "Lab 1", "capacity": 30, "type": "Lab"},
      ];
      data["items"] = {
        "Math": {config.nameLabel: "Math", config.personLabel: "Dr. A", "Capacity": "100", "Type": "Lecture", "available_days": ["Sunday"]},
      };
    } 
    else if (mode == 'Hospital') {
      data["startTime"] = "00:00 AM";
      data["numberOfSlots"] = 3;
      data["slotDuration"] = 480;
      data["breakDuration"] = 0;
      data["locations"] = [
        {"name": "ER Room", "capacity": 10, "type": "Emergency"},
      ];
      data["items"] = {
        "ER Shift": {config.nameLabel: "ER Shift", config.personLabel: "Dr. House", "Type": "Emergency", "available_days": ["Saturday"]},
      };
    }
    else if (mode == 'School') {
      data["startTime"] = "07:30 AM";
      data["numberOfSlots"] = 7;
      data["slotDuration"] = 45;
      data["breakDuration"] = 15;
      data["locations"] = [
        {"name": "Class 1A", "capacity": 35, "type": "Classroom"},
        {"name": "Science Lab", "capacity": 25, "type": "Lab"},
      ];
      data["items"] = {
        "Math Grade 1": {
          config.nameLabel: "Math", 
          config.personLabel: "Mr. Ahmed", 
          "Capacity": "30", "Type": "Lecture", 
          "available_days": ["Sunday", "Monday"]
        },
      };
    }
    else if (mode == 'Event') {
      data["startTime"] = "09:00 AM";
      data["numberOfSlots"] = 4;
      data["slotDuration"] = 60;
      data["breakDuration"] = 30;
      data["locations"] = [
        {"name": "Main Hall", "capacity": 500, "type": "Lecture Hall"},
        {"name": "Meeting Room", "capacity": 20, "type": "Workspace"},
      ];
      data["items"] = {
        "Opening Keynote": {
          config.nameLabel: "Opening Keynote", 
          config.personLabel: "Keynote Speaker", 
          "Capacity": "400", "Type": "Keynote", 
          "available_days": ["Saturday"]
        },
      };
    }

    return data;
  }
}